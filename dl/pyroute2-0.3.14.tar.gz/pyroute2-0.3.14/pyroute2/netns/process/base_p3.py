from pyroute2.netns.process import MetaPopen


class NSPopenBase(object, metaclass=MetaPopen):

    pass
